Skrárnar í þessari möppu eru til viðmiðunar um
hvernig haga má gögnum í verkefninu.

Sumir dálkar eru vísvitandi ekki á réttu formi
og er það hlutverk nemenda að haga gögnunum
eftir verkefnislýsingu.

Bent er á að ekki eru allir dálkar sem fylgja
þessum gögnum nauðsynlegir við úrfærslu
verkefnisins, en eru hafðir með sem dæmi um
að gagnagrunnstöflur innihalda oft meira
en við þurfum fyrir okkar notkunartilvik.

- Arnar Ingi
